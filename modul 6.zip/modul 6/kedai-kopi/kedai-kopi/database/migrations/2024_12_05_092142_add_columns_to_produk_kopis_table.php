<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::table('produk_kopis', function (Blueprint $table) {
            $table->string('nama');
            $table->decimal('harga', 8, 2);
            $table->text('deskripsi');
        });
    }
    
    public function down()
    {
        Schema::table('produk_kopis', function (Blueprint $table) {
            $table->dropColumn(['nama', 'harga', 'deskripsi']);
        });
    }
    
};
