<?php

namespace App\Http\Controllers;

use App\Models\ProdukKopi;
use Illuminate\Http\Request;

class ProdukKopiController extends Controller
{
    public function index()
    {
        return ProdukKopi::all();
    }

    public function store(Request $request)
    {
        $produkKopi = ProdukKopi::create($request->all());
        return response()->json($produkKopi, 201);
    }

    public function show($id)
    {
        return ProdukKopi::find($id);
    }

    public function update(Request $request, $id)
    {
        $produkKopi = ProdukKopi::find($id);
        $produkKopi->update($request->all());
        return response()->json($produkKopi, 200);
    }

    public function destroy($id)
    {
        ProdukKopi::destroy($id);
        return response()->json(null, 204);
    }
}
