<?php

namespace App\Http\Controllers;

use App\Models\BahanBakuKopi;
use Illuminate\Http\Request;

class BahanBakuKopiController extends Controller
{
    public function index()
    {
        return BahanBakuKopi::all();
    }

    public function store(Request $request)
    {
        $bahanBaku = BahanBakuKopi::create($request->all());
        return response()->json($bahanBaku, 201);
    }

    public function show($id)
    {
        return BahanBakuKopi::find($id);
    }

    public function update(Request $request, $id)
    {
        $bahanBaku = BahanBakuKopi::find($id);
        $bahanBaku->update($request->all());
        return response()->json($bahanBaku, 200);
    }

    public function destroy($id)
    {
        BahanBakuKopi::destroy($id);
        return response()->json(null, 204);
    }
}
