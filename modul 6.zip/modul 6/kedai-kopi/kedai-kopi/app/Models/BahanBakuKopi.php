<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BahanBakuKopi extends Model
{
    protected $table = 'bahan_baku_kopis';

    // Tentukan kolom-kolom yang bisa diisi secara mass assignment
    protected $fillable = [
        'nama',
        'stok',
        'harga',
    ];

    protected $dates = ['created_at', 'updated_at'];
}
