<?php


namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProdukKopi extends Model
{
    
    protected $table = 'produk_kopis';

    protected $fillable = [
        'nama',
        'harga',
        'deskripsi',
    ];
}
