<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BahanBakuKopiController;
use App\Http\Controllers\ProdukKopiController;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

Route::apiResource('bahan_baku_kopis', BahanBakuKopiController::class);
Route::apiResource('produk_kopis', ProdukKopiController::class);