// import vue router
import { createRouter, createWebHistory } from "vue-router";

// define routes
const routes = [
  {
    path: "/",
    name: "home",
    component: () => import(/* webpackChunkName: "home" */ "../views/home.vue"),
  },
  // Route for Products
  {
    path: "/bahan_baku_kopis",
    name: "bahan_baku_kopis.index",
    component: () =>
      import(
        /* webpackChunkName: "produk-index" */ "../views/bahan_baku_kopis/index.vue"
      ),
  },
  {
    path: "/bahan_baku_kopis/create", // Ensuring plural naming consistency here
    name: "bahan_baku_kopis.create",
    component: () =>
      import(
        /* webpackChunkName: "produk-create" */ "../views/bahan_baku_kopis/create.vue"
      ),
  },
  {
    path: "/bahan_baku_kopis/edit/:id", // Plural path consistency
    name: "bahan_baku_kopis.edit",
    component: () =>
      import(/* webpackChunkName: "produk-edit" */ "../views/bahan_baku_kopis/edit.vue"),
  },
  // Route for Contacts
  {
    path: "/produk_kopis",
    name: "produk_kopis.index",
    component: () =>
      import(
        /* webpackChunkName: "kontak-index" */ "../views/produk_kopis/index.vue"
      ),
  },
  {
    path: "/produk_kopis/create",
    name: "produk_kopis.create",
    component: () =>
      import(
        /* webpackChunkName: "produk-create" */ "../views/produk_kopis/create.vue"
      ),
  },
  {
    path: "/produk_kopis/edit/:id",
    name: "produk_kopis.edit",
    component: () =>
      import(/* webpackChunkName: "kontak-edit" */ "../views/produk_kopis/edit.vue"),
  },
];

// create router
const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
