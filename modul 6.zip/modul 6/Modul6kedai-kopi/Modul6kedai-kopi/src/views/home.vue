<template>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  
  <!-- fontawesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
  
  <!-- sweetalert2 css -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.7.2/sweetalert2.min.css">
  
</head>
<body>

  
  <!-- navbar end -->
  
  <!-- section hero start -->
  <section class="hero" id="home">
    <div class="content">
      <h1>Yuk kita Nikmatkan <span>secangkir kopi</span></h1>
      <p>Kopi itu sederhana, tapi selalu bisa menciptakan momen yang istimewa.</p>
      <a href="#product" class="button">Beli Sekarang</a>
    </div>
  </section>
  <!-- section hero end -->
  
  <!-- section about start -->
  <section class="about" id="about">
    <h2>Tentang <span>Kami</span></h2>
    <div class="row">
      <div class="image-wrapper">
        <img src="/src/assets/images/about.jpg" width="100" alt="tentang kami" class="image">
      </div>
      <div class="content">
        <h3>Kenapa Memilih Mumtaaz coffe</h3>
        <p>Kopi itu seperti hidup, kadang pahit, tapi selalu memberikan semangat.</p>
        <p>Disini kami menyediakan beberapa menu .</p>
      </div>
    </div>
  </section>
  <!-- section about end -->
  
  <!-- section menu start -->
  <section class="product" id="product">
    <div class="header">
      <h2>Produk <span>Kami</span></h2>
      <p>Disini kami Menyediakan Berbagai Menu untuk Anda</p>
    </div>
    <div class="card-container"></div>
  </section>
  <!-- section menu end -->
  
  <!-- section contact start -->
  <section class="contact" id="contact">
    <div class="header">
      <h2>Kontak <span>Kami</span></h2>
      <p>ini kontak kami supaya mudah menghubungi kami.</p>
    </div>
    <div class="row">
      <div class="image-wrapper">
        <img src="/src/assets/images/contact.jpg" alt="kontak kami" class="image">
      </div>
      <div class="form-wrapper">
        <form action="" class="form">
          <div class="form-group">
            <label for="nama" class="label">Nama lengkap</label>
            <input type="text" id="nama" class="input input-name" placeholder="Nama lengkap">
          </div>
          <div class="form-group">
            <label for="email" class="label">Alamat email</label>
            <input type="text" id="email" class="input input-email" placeholder="Alamat email">
          </div>
          <div class="form-group">
            <label for="nomor" class="label">Nomor telepon</label>
            <input type="number" id="nomor" class="input input-nomor" placeholder="No.telepon">
          </div>
          <button type="submit" class="button btn-submit">Submit</button>
        </form>
      </div>
    </div>
  </section>
  <!-- section contact end -->
  
  <!-- footer start -->
  <footer class="footer">
    <div class="wrapper">
      <a href="https://www.instagram.com/ekacore_?igsh=emFqb3BpeWNqbmV3" target="_blank"><i data-feather="instagram"></i></a>
      <a href="https://www.facebook.com/profile.php?id=100070331124256&mibextid=ZbWKwL" target="_blank"><i data-feather="facebook"></i></a>
      <a href="https://github.com/mumtaaz07/mumtaaz07" target="_blank"><i data-feather="github"></i></a>
    </div>
    <div class="wrapper">
      <a href="#home">Home</a>
      <a href="#about">Tentang Kami</a>
      <a href="#product">Produk Kami</a>
      <a href="#contact">Kontak</a>
    </div>
    <span>created by <a href="https://github.com/candradwicahyo" target="_blank">eka maheswara</a> | © 2024</span>
  </footer>
  <!-- footer end -->
  
  <!-- search input modal start -->
  <div class="modal" data-id="searchModal">
    <div class="modal-header">
      <h3>Search Modal</h3>
      <i data-feather="x-circle" class="btn-modal-close"></i>
    </div>
    <div class="modal-body">
      <div class="form-group">
        <input type="text" class="input search-input" placeholder="ketikkan nama produk ...">
      </div>
      <!-- product container start -->
      <div class="product-container"></div>
      <!-- product container end -->
    </div>
  </div>
  <!-- search input modal end -->
  
  <!-- shopping cart modal start -->
  <div class="modal" data-id="tableModal">
    <div class="modal-header">
      <h3>Shopping Cart Modal</h3>
      <i data-feather="x-circle" class="btn-modal-close"></i>
    </div>
    <div class="modal-body">
      <!-- list start -->
      <div class="box-container"></div>
      <!-- list end -->
      <div class="wrapper">
        <h4>Total Biaya : </h4>
        <span class="price">0</span>
      </div>
      <button class="button button-checkout">Checkout</button>
    </div>
  </div>
  <!-- shopping cart modal end -->
  
</body>
</html>

</template>

<script setup> import {ref} from 'vue'; </script>
<style src="./src/assets/style.css"></style>