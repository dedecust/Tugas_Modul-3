<script setup>
// Import ref
import { ref } from "vue";

// Import router
import { useRouter } from "vue-router";

// Import API
import api from "../../api";

// Inisialisasi router
const router = useRouter();

// Definisikan state
const nama = ref("");
const stok = ref(0);
const harga = ref(0.0);
const errors = ref([]);

// Method "storeBahanBaku" untuk menyimpan data bahan baku
const storeBahanBaku = async () => {
  // Inisialisasi FormData
  let formData = new FormData();

  // Assign nilai state ke dalam formData
  formData.append("nama", nama.value);
  formData.append("stok", stok.value);
  formData.append("harga", harga.value);

  // Kirim data dengan API untuk membuat bahan baku baru
  await api
    .post("/bahan_baku_kopis", formData)
    .then(() => {
      // Redirect setelah bahan baku berhasil disimpan
      router.push({ path: "/bahan_baku_kopis" });
    })
    .catch((error) => {
      // Menyimpan pesan error jika ada
      errors.value = error.response.data.errors;
    });
};
</script>

<template>
  <div class="container mt-5">
    <div class="row">
      <div class="col-md-12">
        <div class="card border-0 rounded shadow">
          <div class="card-body">
            <form @submit.prevent="storeBahanBaku()">
              <!-- Input untuk nama -->
              <div class="mb-3">
                <label class="form-label fw-bold">Nama</label>
                <input
                  type="text"
                  class="form-control"
                  v-model="nama"
                  placeholder="Nama Bahan Baku"
                />
                <div v-if="errors.nama" class="alert alert-danger mt-2">
                  <span>{{ errors.nama[0] }}</span>
                </div>
              </div>

              <!-- Input untuk stok -->
              <div class="mb-3">
                <label class="form-label fw-bold">Stok</label>
                <input
                  type="number"
                  class="form-control"
                  v-model="stok"
                  placeholder="Stok Bahan Baku"
                />
                <div v-if="errors.stok" class="alert alert-danger mt-2">
                  <span>{{ errors.stok[0] }}</span>
                </div>
              </div>

              <!-- Input untuk harga -->
              <div class="mb-3">
                <label class="form-label fw-bold">Harga</label>
                <input
                  type="number"
                  step="0.01"
                  class="form-control"
                  v-model="harga"
                  placeholder="Harga Bahan Baku"
                />
                <div v-if="errors.harga" class="alert alert-danger mt-2">
                  <span>{{ errors.harga[0] }}</span>
                </div>
              </div>

              <!-- Tombol submit -->
              <button
                type="submit"
                class="btn btn-md btn-primary rounded-sm shadow border-0"
              >
                Save
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
