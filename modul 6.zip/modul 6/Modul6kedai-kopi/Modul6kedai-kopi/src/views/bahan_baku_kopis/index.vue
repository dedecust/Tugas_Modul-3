<script setup>
// Import ref dan onMounted
import { ref, onMounted } from "vue";

// Import API
import api from "../../api";

// Definisikan state
const bahanBaku = ref([]);

// Method fetchDataBahanBaku
const fetchDataBahanBaku = async () => {
  // Ambil data bahan baku
  await api
    .get("/bahan_baku_kopis")
    .then((response) => {
      // Set data response ke state "bahanBaku"
      bahanBaku.value = response.data;
    })
    .catch((error) => {
      console.error("Gagal mengambil data bahan baku: ", error);
    });
};

// Run hook "onMounted"
onMounted(() => {
  // Panggil method fetchDataBahanBaku
  fetchDataBahanBaku();
});

// Method deleteBahanBaku
const deleteBahanBaku = async (id) => {
  // Hapus bahan baku dengan API
  await api
    .delete(`/bahan_baku_kopis/${id}`)
    .then(() => {
      // Panggil method "fetchDataBahanBaku" setelah bahan baku dihapus
      fetchDataBahanBaku();
    })
    .catch((error) => {
      console.error("Gagal menghapus bahan baku: ", error);
    });
};
</script>

<template>
  <div class="container mt-5 mb-5">
    <div class="row">
      <div class="col-md-12">
        <!-- Tombol untuk menambahkan bahan baku baru -->
        <router-link
          :to="{ name: 'bahan_baku_kopis.create' }"
          class="btn btn-md btn-success rounded shadow border-0 mb-3"
        >
          ADD NEW BAHAN BAKU
        </router-link>
        <div class="card border-0 rounded shadow">
          <div class="card-body">
            <table class="table table-bordered">
              <thead class="bg-dark text-white">
                <tr>
                  <th scope="col">Nama</th>
                  <th scope="col">Stok</th>
                  <th scope="col">Harga</th>
                  <th scope="col" style="width: 15%">Actions</th>
                </tr>
              </thead>
              <tbody>
                <tr v-if="bahanBaku.length === 0">
                  <td colspan="4" class="text-center">
                    <div class="alert alert-danger mb-0">
                      Data Belum Tersedia!
                    </div>
                  </td>
                </tr>
                <tr v-else v-for="(item, index) in bahanBaku" :key="index">
                  <td>{{ item.nama }}</td>
                  <td>{{ item.stok }}</td>
                  <td>{{ item.harga }}</td>
                  <td class="text-center">
                    <!-- Tombol untuk edit bahan baku -->
                    <router-link
                      :to="{ name: 'bahan_baku_kopis.edit', params: { id: item.id } }"
                      class="btn btn-sm btn-primary rounded-sm shadow border-0 me-2"
                    >
                      EDIT
                    </router-link>
                    <!-- Tombol untuk delete bahan baku -->
                    <button
                      @click.prevent="deleteBahanBaku(item.id)"
                      class="btn btn-sm btn-danger rounded-sm shadow border-0"
                    >
                      DELETE
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
