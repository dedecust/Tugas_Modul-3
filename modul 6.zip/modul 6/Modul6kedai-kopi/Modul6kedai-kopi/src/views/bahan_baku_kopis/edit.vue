<script setup>
// Import ref dan onMounted
import { ref, onMounted } from "vue";

// Import router dan route
import { useRouter, useRoute } from "vue-router";

// Import API
import api from "../../api";

// Inisialisasi router
const router = useRouter();

// Inisialisasi route
const route = useRoute();

// Definisikan state
const nama = ref("");
const stok = ref(0);
const harga = ref(0.0);
const errors = ref([]);

// onMounted
onMounted(async () => {
  // Ambil data bahan baku berdasarkan ID dari API
  await api.get(`/bahan_baku_kopis/${route.params.id}`).then((response) => {
    // Set data response ke state
    nama.value = response.data.data.nama;
    stok.value = response.data.data.stok;
    harga.value = response.data.data.harga;
  });
});

// Method "updateBahanBaku"
const updateBahanBaku = async () => {
  // Kirim data dengan API
  await api
    .patch(`/bahan_baku_kopis/${route.params.id}`, {
      nama: nama.value,
      stok: stok.value,
      harga: harga.value,
    })
    .then(() => {
      // Redirect setelah data berhasil diperbarui
      router.push({ path: "/bahan_baku_kopis" });
    })
    .catch((error) => {
      // Assign data error response ke state "errors"
      errors.value = error.response.data.errors;
    });
};
</script>

<template>
  <div class="container mt-5">
    <div class="row">
      <div class="col-md-12">
        <div class="card border-0 rounded shadow">
          <div class="card-body">
            <form @submit.prevent="updateBahanBaku()">
              <!-- Input untuk nama -->
              <div class="mb-3">
                <label class="form-label fw-bold">Nama</label>
                <input
                  type="text"
                  class="form-control"
                  v-model="nama"
                  placeholder="Nama Bahan Baku"
                />
                <div v-if="errors.nama" class="alert alert-danger mt-2">
                  <span>{{ errors.nama[0] }}</span>
                </div>
              </div>

              <!-- Input untuk stok -->
              <div class="mb-3">
                <label class="form-label fw-bold">Stok</label>
                <input
                  type="number"
                  class="form-control"
                  v-model="stok"
                  placeholder="Stok Bahan Baku"
                />
                <div v-if="errors.stok" class="alert alert-danger mt-2">
                  <span>{{ errors.stok[0] }}</span>
                </div>
              </div>

              <!-- Input untuk harga -->
              <div class="mb-3">
                <label class="form-label fw-bold">Harga</label>
                <input
                  type="number"
                  step="0.01"
                  class="form-control"
                  v-model="harga"
                  placeholder="Harga Bahan Baku"
                />
                <div v-if="errors.harga" class="alert alert-danger mt-2">
                  <span>{{ errors.harga[0] }}</span>
                </div>
              </div>

              <!-- Tombol submit -->
              <button
                type="submit"
                class="btn btn-md btn-primary rounded-sm shadow border-0"
              >
                Update
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
