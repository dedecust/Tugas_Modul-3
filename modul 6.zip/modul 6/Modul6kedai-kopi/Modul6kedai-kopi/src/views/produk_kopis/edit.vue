<script setup>
// Import ref dan onMounted
import { ref, onMounted } from "vue";

// Import router dan route
import { useRouter, useRoute } from "vue-router";

// Import API
import api from "../../api";

// Inisialisasi router
const router = useRouter();
const route = useRoute();

// Definisikan state
const nama = ref("");
const harga = ref("");
const deskripsi = ref("");
const image = ref("");
const errors = ref([]);

// onMounted
onMounted(async () => {
  // Ambil data produk berdasarkan ID dari API
  await api.get(`/produk_kopis/${route.params.id}`).then((response) => {
    // Set data response ke state
    const data = response.data.data;
    nama.value = data.nama;
    harga.value = data.harga;
    deskripsi.value = data.deskripsi;
  });
});

// Method untuk menangani perubahan file
const handleFileChange = (e) => {
  // Assign file ke state image
  image.value = e.target.files[0];
};

// Method "updateProduk"
const updateProduk = async () => {
  let formData = new FormData();
  formData.append("nama", nama.value);
  formData.append("harga", harga.value);
  formData.append("deskripsi", deskripsi.value);
  if (image.value) formData.append("image", image.value);
  formData.append("_method", "PATCH");

  await api
    .post(`/produk_kopis/${route.params.id}`, formData)
    .then(() => {
      router.push({ path: "/produk_kopis" });
    })
    .catch((error) => {
      errors.value = error.response.data.errors;
    });
};
</script>

<template>
  <div class="container mt-5">
    <div class="row">
      <div class="col-md-12">
        <div class="card border-0 rounded shadow">
          <div class="card-body">
            <form @submit.prevent="updateProduk()">
              <!-- Input untuk nama produk -->
              <div class="mb-3">
                <label class="form-label fw-bold">Nama Produk</label>
                <input
                  type="text"
                  class="form-control"
                  v-model="nama"
                  placeholder="Nama Produk"
                />
                <div v-if="errors.nama" class="alert alert-danger mt-2">
                  <span>{{ errors.nama[0] }}</span>
                </div>
              </div>

              <!-- Input untuk harga -->
              <div class="mb-3">
                <label class="form-label fw-bold">Harga</label>
                <input
                  type="number"
                  class="form-control"
                  v-model="harga"
                  placeholder="Harga Produk"
                />
                <div v-if="errors.harga" class="alert alert-danger mt-2">
                  <span>{{ errors.harga[0] }}</span>
                </div>
              </div>

              <!-- Input untuk deskripsi -->
              <div class="mb-3">
                <label class="form-label fw-bold">Deskripsi</label>
                <textarea
                  class="form-control"
                  v-model="deskripsi"
                  placeholder="Deskripsi Produk"
                ></textarea>
                <div v-if="errors.deskripsi" class="alert alert-danger mt-2">
                  <span>{{ errors.deskripsi[0] }}</span>
                </div>
              </div>

              <!-- Input untuk image -->
              <!-- <div class="mb-3">
                <label class="form-label fw-bold">Image</label>
                <input
                  type="file"
                  class="form-control"
                  @change="handleFileChange($event)"
                />
                <div v-if="errors.image" class="alert alert-danger mt-2">
                  <span>{{ errors.image[0] }}</span>
                </div>
              </div> -->

              <!-- Tombol submit -->
              <button
                type="submit"
                class="btn btn-md btn-primary rounded-sm shadow border-0"
              >
                Update
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
