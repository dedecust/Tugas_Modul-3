<script setup>
// Import ref
import { ref } from "vue";

// Import router
import { useRouter } from "vue-router";

// Import API
import api from "../../api";

// Inisialisasi router
const router = useRouter();

// Definisikan state
const nama = ref("");
const harga = ref("");
const deskripsi = ref("");
const errors = ref([]);

// Method "storeProduk" untuk menyimpan data produk
const storeProduk = async () => {
  // Inisialisasi FormData
  let formData = new FormData();

  // Assign nilai state ke dalam formData
  formData.append("nama", nama.value);
  formData.append("harga", harga.value);
  formData.append("deskripsi", deskripsi.value);

  // Kirim data dengan API untuk membuat produk baru
  await api
    .post("/produk_kopis", formData)
    .then(() => {
      // Redirect setelah produk berhasil disimpan
      router.push({ path: "/produk_kopis" });
    })
    .catch((error) => {
      // Menyimpan pesan error jika ada
      errors.value = error.response.data.errors;
    });
};
</script>

<template>
  <div class="container mt-5">
    <div class="row">
      <div class="col-md-12">
        <div class="card border-0 rounded shadow">
          <div class="card-body">
            <form @submit.prevent="storeProduk()">
              <!-- Input untuk nama -->
              <div class="mb-3">
                <label class="form-label fw-bold">Nama</label>
                <input
                  type="text"
                  class="form-control"
                  v-model="nama"
                  placeholder="Nama Produk"
                />
                <div v-if="errors.nama" class="alert alert-danger mt-2">
                  <span>{{ errors.nama[0] }}</span>
                </div>
              </div>

              <!-- Input untuk harga -->
              <div class="mb-3">
                <label class="form-label fw-bold">Harga</label>
                <input
                  type="number"
                  class="form-control"
                  v-model="harga"
                  placeholder="Harga Produk"
                />
                <div v-if="errors.harga" class="alert alert-danger mt-2">
                  <span>{{ errors.harga[0] }}</span>
                </div>
              </div>

              <!-- Input untuk deskripsi -->
              <div class="mb-3">
                <label class="form-label fw-bold">Deskripsi</label>
                <textarea
                  class="form-control"
                  v-model="deskripsi"
                  placeholder="Deskripsi Produk"
                ></textarea>
                <div v-if="errors.deskripsi" class="alert alert-danger mt-2">
                  <span>{{ errors.deskripsi[0] }}</span>
                </div>
              </div>

              <!-- Tombol submit -->
              <button
                type="submit"
                class="btn btn-md btn-primary rounded-sm shadow border-0"
              >
                Save
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
