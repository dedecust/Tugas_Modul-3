<?php

require_once 'VehicleManagement/Car.php';
require_once 'VehicleManagement/Motorcycle.php';
require_once 'VehicleManagement/VehicleInfo.php';

use VehicleManagement\Car;
use VehicleManagement\Motorcycle;
use VehicleManagement\VehicleInfo;

// Membuat objek Car dan Motorcycle
$car = new Car("Toyota", "Corolla", 5);
$motorcycle = new Motorcycle("Yamaha", "YZF-R3", "Sport");

// Menampilkan deskripsi kendaraan
echo $car->getDescription() . "\n";
echo $motorcycle->getDescription() . "\n";

// Mengisi bahan bakar
$car->refuel(50);
$motorcycle->refuel(15);

// Magic method __toString untuk VehicleInfo
$vehicleInfo = new VehicleInfo($car);
echo $vehicleInfo . "\n";
