<?php

namespace VehicleManagement;

require_once 'Vehicle.php';

class VehicleInfo {
    private $vehicle;

    public function __construct(Vehicle $vehicle) {
        $this->vehicle = $vehicle;
    }

    public function __toString() {
        return $this->vehicle->getDescription();
    }
}
