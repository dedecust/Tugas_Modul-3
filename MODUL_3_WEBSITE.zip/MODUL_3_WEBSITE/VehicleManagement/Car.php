<?php

namespace VehicleManagement;

require_once 'Vehicle.php';
require_once 'FuelTrait.php';

class Car extends Vehicle {
    use FuelTrait;

    private $seatingCapacity;

    public function __construct($brand, $model, $seatingCapacity) {
        parent::__construct($brand, $model);
        $this->seatingCapacity = $seatingCapacity;
    }

    public function getDescription() {
        return "This is a car: {$this->brand} {$this->model} with seating capacity of {$this->seatingCapacity}.";
    }
}
