<?php

namespace VehicleManagement;

abstract class Vehicle {
    protected $brand;
    protected $model;

    public function __construct($brand, $model) {
        $this->brand = $brand;
        $this->model = $model;
    }

    abstract public function getDescription();

    public function startEngine() {
        echo "The engine of {$this->brand} {$this->model} is starting...\n";
    }
}
