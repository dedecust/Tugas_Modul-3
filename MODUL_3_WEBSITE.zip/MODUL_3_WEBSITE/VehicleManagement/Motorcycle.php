<?php

namespace VehicleManagement;

require_once 'Vehicle.php';
require_once 'FuelTrait.php';

class Motorcycle extends Vehicle {
    use FuelTrait;

    private $type;

    public function __construct($brand, $model, $type) {
        parent::__construct($brand, $model);
        $this->type = $type;
    }

    public function getDescription() {
        return "This is a motorcycle: {$this->brand} {$this->model} of type {$this->type}.";
    }
}
