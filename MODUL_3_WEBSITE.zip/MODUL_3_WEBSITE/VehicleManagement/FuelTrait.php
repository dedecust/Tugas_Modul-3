<?php

namespace VehicleManagement;

trait FuelTrait {
    public function refuel($amount) {
        echo "Refueling with $amount liters...\n";
    }
}
